<?php
$server_name = "localhost";
$username = "root";
$pass = "";
$db_name = "qr_attendance";

$connection = mysqli_connect($server_name, $username, $pass, $db_name);
